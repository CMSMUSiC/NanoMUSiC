sample_list = [
    # (process_name, das_name, year, is_data)
    (
        "DYJetsToLL_M-50_13TeV_AM",
        "/DYJetsToLL_M-50_TuneCP5_13TeV-amcatnloFXFX-pythia8/RunIISummer20UL17NanoAODv9-106X_mc2017_realistic_v9-v2/NANOAODSIM",
        "2017",
        False,
    ),
    (
        "SingleMuonB_2017",
        "/SingleMuon/Run2017B-UL2017_MiniAODv2_NanoAODv9-v1/NANOAOD",
        "2017",
        True,
    ),
    (
        "SingleMuonC_2017",
        "/SingleMuon/Run2017C-UL2017_MiniAODv2_NanoAODv9-v1/NANOAOD",
        "2017",
        True,
    ),
    (
        "SingleMuonD_2017",
        "/SingleMuon/Run2017D-UL2017_MiniAODv2_NanoAODv9-v1/NANOAOD",
        "2017",
        True,
    ),
    (
        "SingleMuonE_2017",
        "/SingleMuon/Run2017E-UL2017_MiniAODv2_NanoAODv9-v1/NANOAOD",
        "2017",
        True,
    ),
    (
        "SingleMuonF_2017",
        "/SingleMuon/Run2017F-UL2017_MiniAODv2_NanoAODv9-v1/NANOAOD",
        "2017",
        True,
    ),
]




